using Fusion;

namespace Vermines.Core.Network {

    public struct SessionRequest {

        public string UserID;

        public GameMode GameMode;
        public GameplayType GameplayType;

        public string SessionName;
        public string ScenePath;
        public string CustomLobby;

        public bool IsCustom;
        public bool IsGameSession;

        /// <summary>
        /// True = the end of this session brings the player back to the main menu instead of the tavern (e.g., a tutorial lesson).
        /// </summary>
        public bool ReturnToMainMenu;

        public int MaxPlayers;

        /// <summary>
        /// Number of players expected before gameplay initialization.
        /// 0 keeps the current snapshot behaviour (custom lobby scene change).
        /// </summary>
        public int ExpectedPlayers;
        public int ExtraPeers;

        public string IPAddress;
        public ushort Port;
    }
}
