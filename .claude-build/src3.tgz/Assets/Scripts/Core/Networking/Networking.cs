using UnityEngine.SceneManagement;
using UnityEngine;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Collections;
using System;
using Fusion.Sockets;
using Fusion;

namespace Vermines.Core.Network {

    using UnityScene = UnityEngine.SceneManagement.Scene;

    using Vermines.Extension;
    using Vermines.Core.Scene;
    using Vermines.Menu.CustomLobby;
    using Vermines.Core.Services;
    using Vermines.Menu.View;

    public class Networking : MonoBehaviour {

        #region Constant

        public const string STATUS_SERVER_CLOSED = "server_closed";

        public const string MODE_KEY     = "mode";
        public const string TYPE_KEY     = "type";
        public const string CUSTOM_KEY   = "custom";
        public const string GAME_SESSION = "game_s";

        private const float CONNECTION_LOST_GRACE = 3f;

        #endregion

        #region Attributes

        public string Status { get; private set; }
        public string StatusDescription { get; private set; }
        public string ErrorStatus { get; private set; }

        private Session _PendingSession;
        private Session _CurrentSession;

        private bool _StopGameOnDisconnect;

        private string _LoadingScene;

        private Coroutine _Coroutine;

        private bool _IsChangeScene;

        #endregion

        #region MonoBehaviour Methods

        protected void Awake()
        {
            _LoadingScene = Global.Settings.LoadingScene;
        }

        protected void Update()
        {
            if (_IsChangeScene)
                return;
            if (_PendingSession != null) {
                if (_CurrentSession == null) {
                    _CurrentSession = _PendingSession;
                    _PendingSession = null;
                } else {
                    // Request the end of the current session.
                    _CurrentSession.ConnectionRequested = false;
                }
            }

            UpdateCurrentSession();

            // Check if current session finished
            if (_Coroutine == null && _CurrentSession != null && !_CurrentSession.IsConnected) {
                if (_PendingSession == null) {
                    Log($"Starting LoadMenuCoroutine().");

                    // Current session is finished and there is no pending session, let's go to menu.
                    _Coroutine = StartCoroutine(LoadMenuCoroutine(ReturnsToMainMenu(_CurrentSession)));
                }

                _CurrentSession = null;
            }
        }

        #endregion

        #region Methods

        #region Game

        public void StartGame(SessionRequest request)
        {
            Session session = new();

            if (request.ExtraPeers > 0 && NetworkProjectConfig.Global.PeerMode == NetworkProjectConfig.PeerModes.Single) {
                Debug.LogError("Cannot start with multiple peers. PeerMode is set to Single.");

                request.ExtraPeers = 0;
            }
            SceneRef sceneRef = default;

            int sceneIndex = SceneUtility.GetBuildIndexByScenePath(request.ScenePath);

            if (sceneIndex >= 0)
                sceneRef = SceneRef.FromIndex(sceneIndex);
            int totalPeers = 1 + request.ExtraPeers;

            session.GamePeers = new GamePeer[totalPeers];

            NetworkSceneInfo sceneInfo = new();

            if (sceneRef.IsValid)
                sceneInfo.AddSceneRef(sceneRef, LoadSceneMode.Additive, LocalPhysicsMode.None, true);
            for (int i = 0; i < totalPeers; i++) {
                session.GamePeers[i] = new(i) {
                    UserID   = i == 0 ? request.UserID : $"{request.UserID}.{i}",
                    Scene    = sceneInfo,
                    GameMode = i == 0 ? request.GameMode : GameMode.Client,
                    Request  = request
                };
            }
            session.ConnectionRequested = true;

            _PendingSession       = session;
            _StopGameOnDisconnect = false;
            ErrorStatus           = null;

            Log($"StartGame() UserID:{request.UserID} GameMode:{request.GameMode} SessionName:{request.SessionName} ScenePath:{request.ScenePath} MaxPlayers:{request.MaxPlayers} ExtraPeers:{request.ExtraPeers} CustomLobby:{request.CustomLobby} GameplayType: {request.GameplayType}");
        }

        public void StopGame(string errorStatus = null)
        {
            Log($"StopGame()");

            _PendingSession       = null;
            _StopGameOnDisconnect = false;

            if (_CurrentSession != null)
                _CurrentSession.ConnectionRequested = false;
            else if (_Coroutine == null)
                _Coroutine = StartCoroutine(LoadMenuCoroutine());
            ErrorStatus = errorStatus;
        }

        public void StopGameOnDisconnect()
        {
            Log($"StopGameOnDisconnect()");

            _StopGameOnDisconnect = true;
        }

        /// <summary>
        /// Loads the Matchmaking scene without Fusion so the player can search for a match immediately.
        /// </summary>
        public void EnterMatchmakingSearch(string scenePath)
        {
            if (_Coroutine != null)
                return;
            _Coroutine = StartCoroutine(EnterMatchmakingSearchCoroutine(scenePath));
        }

        #endregion

        public void UpdateCurrentSession()
        {
            if (_IsChangeScene)
                return;
            if (_CurrentSession == null) {
                Status            = string.Empty;
                StatusDescription = string.Empty;

                return;
            }

            if (_Coroutine != null)
                return;
            GamePeer[] peers = _CurrentSession.GamePeers;

            if (_StopGameOnDisconnect) {
                for (int i = 0; i < peers.Length; i++) {
                    if (_CurrentSession.ConnectionRequested && !peers[i].IsConnected) {
                        Log($"Stopping game after disconnect.");

                        _StopGameOnDisconnect = false;

                        StopGame();

                        return;
                    }
                }
            }

            for (int i = 0; i < peers.Length; i++) {
                GamePeer    peer = peers[i];
                bool isConnected = peer.IsConnected;

                if (isConnected)
                    peer.DisconnectDetectedAt = null;

                if (_CurrentSession.ConnectionRequested && !peer.Loaded && !isConnected && peer.CanConnect) { // First connect or reconnect after failed connect
                    Status = !peer.WasConnected ? "starting" : "reconnecting";

                    Log($"Starting ConnectPeerCoroutine() - {Status} - Peer {peer.ID}");

                    _Coroutine = StartCoroutine(ConnectPeerCoroutine(peer));

                    return;
                } else if (!_CurrentSession.ConnectionRequested && (isConnected || peer.Loaded)) { // Disconnect Request
                    Status = "quitting";

                    Log($"Starting DisconnectPeerCoroutine() - {Status} - Peer {peer.ID}");

                    _Coroutine = StartCoroutine(DisconnectPeerCoroutine(peer));

                    return;
                } else if (peer.Loaded && !isConnected) { // Connection Lost
                    peer.DisconnectDetectedAt ??= Time.realtimeSinceStartup;

                    if (Time.realtimeSinceStartup - peer.DisconnectDetectedAt.Value < CONNECTION_LOST_GRACE)
                        continue;

                    Status = "connexion_lost";

                    Log($"Starting DisconnectPeerCoroutine() - {Status} - Peer {peer.ID}");

                    _Coroutine = StartCoroutine(DisconnectPeerCoroutine(peer));

                    return;
                }
            }
        }

        public void ClearErrorStatus()
        {
            ErrorStatus = null;
        }

        #endregion

        #region Coroutine

        #region Peers



        private IEnumerator ConnectPeerCoroutine(GamePeer peer, float connectionTimeout = 20f, float loadTimeout = 45f)
        {
            peer.Loaded = true;

            bool success = false;

            try {
                StatusDescription = "unloading_current_scene";

                if (!IsSceneLoaded(peer.Request.ScenePath) && !IsSceneLoaded(_LoadingScene)) {
                    Log($"Show loading scene.");

                    yield return ShowLoadingSceneCoroutine(true);

                    List<UnityScene> scenesToUnload = GetScenesToUnload();

                    for (int i = 0; i < _CurrentSession.GamePeers.Length; i++) {
                        if (scenesToUnload.Contains(_CurrentSession.GamePeers[i].LoadedScene)) {
                            scenesToUnload.Remove(_CurrentSession.GamePeers[i].LoadedScene);

                            break;
                        }
                    }

                    foreach (UnityScene s in scenesToUnload) {
                        Scene currentScene = s.GetComponent<Scene>();

                        if (currentScene != null) {
                            Log($"Deinitializing Scene.");

                            currentScene.Deinitialize();
                        }

                        Log($"Unloading scene {s.name}");

                        yield return PersistentSceneService.Instance.UnloadScene(s.name);
                        yield return null;
                    }
                }

                float baseTime  = Time.realtimeSinceStartup;
                float limitTime = baseTime + connectionTimeout;
                string peerName = $"{peer.GameMode}#{peer.ID}";

                Debug.LogWarning($"Starting {peerName} ...");

                StatusDescription = "starting_network_connection";

                yield return null;

                NetworkRunner   runner = null;
                StartGameResult result = default;

                bool isClientOrAuto = peer.GameMode == GameMode.Client || peer.GameMode == GameMode.AutoHostOrClient;
                int joinAttempts    = isClientOrAuto ? 8 : 1;

                if (isClientOrAuto)
                    yield return new WaitForSeconds(0.75f);
                for (int attempt = 0; attempt < joinAttempts; attempt++) {
                    if (runner != null) {
                        Log($"Recreating NetworkRunner before join retry ({attempt + 1}/{joinAttempts}).");

                        Task shutdownTask = null;

                        try {
                            shutdownTask = runner.Shutdown(true);
                        } catch (Exception exception) {
                            Debug.LogException(exception);
                        }

                        if (shutdownTask != null) {
                            while (!shutdownTask.IsCompleted)
                                yield return null;
                        }

                        Destroy(runner.gameObject);

                        runner            = null;
                        peer.Runner       = null;
                        peer.SceneManager = null;
                        peer.NetworkPool  = null;

                        yield return new WaitForSeconds(0.5f);
                    }

                    peer.NetworkPool = new();
                    runner           = Instantiate(Global.Settings.RunnerPrefab);
                    runner.name      = peerName;

                    runner.EnableVisibilityExtension();

                    peer.Runner       = runner;
                    peer.SceneManager = runner.GetComponent<NetworkSceneManager>();
                    peer.LoadedScene  = default;

                    StartGameArgs startGameArgs = new() {
                        GameMode                    = peer.GameMode,
                        SessionName                 = peer.Request.SessionName,
                        Scene                       = peer.Scene,
                        ObjectProvider              = peer.NetworkPool,
                        CustomLobbyName             = peer.Request.CustomLobby,
                        SceneManager                = peer.SceneManager,
                        EnableClientSessionCreation = peer.GameMode != GameMode.Client
                    };

                    if (peer.Request.MaxPlayers > 0)
                        startGameArgs.PlayerCount = peer.Request.MaxPlayers;
                    if (peer.GameMode == GameMode.Server || peer.GameMode == GameMode.Host)
                        startGameArgs.SessionProperties = CreateSessionProperties(peer.Request);
                    if (!peer.Request.IPAddress.IsNullOrEmpty())
                        startGameArgs.Address = NetAddress.CreateFromIpPort(peer.Request.IPAddress, peer.Request.Port);
                    else if (peer.Request.Port > 0)
                        startGameArgs.Address = NetAddress.Any(peer.Request.Port);

                    Log($"NetworkRunner.StartGame().");

                    var startGameTask = runner.StartGame(startGameArgs);

                    while (!startGameTask.IsCompleted) {
                        yield return null;

                        if (Time.realtimeSinceStartup >= limitTime) {
                            Debug.LogError($"{peerName} start timeout! IsCompleted: {startGameTask.IsCompleted} IsCanceled: {startGameTask.IsCanceled} IsFaulted: {startGameTask.IsFaulted}");

                            break;
                        }

                        if (!_CurrentSession.ConnectionRequested) {
                            Log($"Stopping coroutine (requested by user");

                            break;
                        }
                    }

                    if (startGameTask.IsCanceled || startGameTask.IsFaulted || !startGameTask.IsCompleted)
                        break;

                    result = startGameTask.Result;

                    if (result.Ok)
                        break;
                    if (!isClientOrAuto || result.ShutdownReason != ShutdownReason.GameNotFound || attempt == joinAttempts - 1)
                        break;
                    Log($"Session not ready yet, retrying join ({attempt + 1}/{joinAttempts}).");
                }

                if (runner == null || !result.Ok) {
                    Debug.LogError($"{peerName} failed to start!");
                    Log($"Starting DisconnectPeerCoroutine() - Peer {peer.ID}.");

                    yield return DisconnectPeerCoroutine(peer);

                    yield break;
                }

                Log($"StartGame() Result: {result} - Peer {peer.ID}.");

                if (!result.Ok) {
                    Debug.LogError($"{peerName} failed to start! Result: {result}");

                    if (!Application.isBatchMode)
                        StopGame();
                    if (peer.WasConnected && result.ShutdownReason == ShutdownReason.GameNotFound)
                        ErrorStatus = STATUS_SERVER_CLOSED;
                    else
                        ErrorStatus = StringToLabel(result.ShutdownReason.ToString());
                    Log($"Starting DisconnectPeerCoroutine() - Peer {peer.ID}.");

                    yield return DisconnectPeerCoroutine(peer);

                    yield break;
                }

                limitTime += loadTimeout;

                Log($"Waiting for connection - Peer {peer.ID}.");

                StatusDescription = "waiting_server_connection";

                while (!peer.IsConnected) {
                    yield return null;

                    if (Time.realtimeSinceStartup >= limitTime) {
                        Debug.LogError($"{peerName} start timeout! IsCloudReady: {runner.IsCloudReady} IsRunning: {runner.IsRunning}");
                        Log($"Starting DisconnectPeerCoroutine() - Peer {peer.ID}.");

                        yield return DisconnectPeerCoroutine(peer);

                        yield break;
                    }
                }

                Log($"Loading gameplay scene - Peer {peer.ID}");

                StatusDescription = "loading_gameplay_scene";

                while (!runner.SimulationUnityScene.IsValid() || !runner.SimulationUnityScene.isLoaded) {
                    Log($"Waiting for NetworkRunner.SimulationUnityScene - Peer {peer.ID}.");

                    yield return null;

                    if (Time.realtimeSinceStartup >= limitTime) {
                        Debug.LogError($"{peerName} scene load timeout!");
                        Log($"Starting DisconnectPeerCoroutine() - Peer {peer.ID}.");

                        yield return DisconnectPeerCoroutine(peer);

                        yield break;
                    }
                }

                Debug.LogWarning($"{peerName} started in {(Time.realtimeSinceStartup - baseTime):0.00}s");

                peer.LoadedScene = runner.SimulationUnityScene;

                StatusDescription = "waiting_gameplay_scene_load";

                var scene = peer.SceneManager.GameplayScene;

                while (scene == null) {
                    Log($"Waiting for GameplayScene - Peer {peer.ID}.");

                    yield return null;

                    scene = peer.SceneManager.GameplayScene;

                    if (Time.realtimeSinceStartup >= limitTime) {
                        Debug.LogError($"{peerName} GameplayScene query timeout!");
                        Log($"Starting DisconnectPeerCoroutine() - Peer {peer.ID}.");

                        yield return DisconnectPeerCoroutine(peer);

                        yield break;
                    }
                }

                Log($"Scene.PrepareContext() - Peer {peer.ID}");

                scene.PrepareContext();

                var sceneContext = scene.Context;

                sceneContext.IsVisible  = peer.ID == 0;
                sceneContext.HasInput   = peer.ID == 0;
                sceneContext.Runner     = peer.Runner;
                sceneContext.PeerUserID = peer.UserID;

                peer.Context             = sceneContext;
                peer.NetworkPool.Context = sceneContext;

                StatusDescription = "waiting_networked_game";

                ContextBehaviour networkManager = null;

                if (peer.Request.IsGameSession)
                    networkManager = scene.GetComponentInChildren<NetworkGame>(true);
                else
                    networkManager = scene.GetComponentInChildren<NetworkLobby>(true);

                while (networkManager.Object == null) {
                    Log($"Waiting for NetworkGame - Peer {peer.ID}");

                    yield return null;

                    if (Time.realtimeSinceStartup >= limitTime) {
                        Debug.LogError($"{peerName} start timeout! Network game not started properly.");
                        Log($"Starting DisconnectPeerCoroutine() - Peer {peer.ID}.");

                        yield return DisconnectPeerCoroutine(peer);

                        yield break;
                    }

                    if (!_CurrentSession.ConnectionRequested) {
                        Log($"Starting DisconnectPeerCoroutine() - Connection is not requested anymore - Peer {peer.ID}.");

                        yield return DisconnectPeerCoroutine(peer);

                        yield break;
                    }
                }

                StatusDescription = "waiting_gameplay_load";

                Log($"NetworkGame.Initialize() - Peer {peer.ID}");

                NetworkLobby lobby = null;
                NetworkGame game   = null;

                if (networkManager is NetworkLobby nl) {
                    nl.Initialize();

                    lobby = nl;

                    while (scene.Context.Lobby == null) {
                        Log($"Waiting for LobbyManager - Peer {peer.ID}");

                        yield return null;

                        if (Time.realtimeSinceStartup >= limitTime) {
                            Debug.LogError($"{peerName} start timeout! LobbyManager not started properly.");

                            Log($"Starting DisconnectPeerCoroutine() - Peer {peer.ID}");

                            yield return DisconnectPeerCoroutine(peer);

                            yield break;
                        }
                    }
                } else if (networkManager is NetworkGame ng) {
                    ng.Initialize(peer.Request.GameplayType, expectedPlayers: peer.Request.ExpectedPlayers);

                    game = ng;

                    // For direct game sessions (matchmaker), the GameplayMode is spawned asynchronously by the host.
                    // We only wait briefly for Context.GameplayMode to be set, but we do NOT block on local player spawn or gameplay state — those happen after Activate().
                    while (scene.Context.GameplayMode == null) {
                        Log($"Waiting for GameplayMode - Peer {peer.ID}");

                        yield return null;

                        if (Time.realtimeSinceStartup >= limitTime) {
                            Debug.LogError($"{peerName} start timeout! Gameplay not started properly.");

                            Log($"Starting DisconnectPeerCoroutine() - Peer {peer.ID}");

                            yield return DisconnectPeerCoroutine(peer);

                            yield break;
                        }
                    }
                }

                StatusDescription = "activating_scene";

                Log($"Scene.Initialize() - Peer {peer.ID}");

                scene.Initialize();

                Log($"Scene.Activate() - Peer {peer.ID}");

                yield return scene.Activate();

                StatusDescription = "activating_network_game";

                Log($"NetworkGame.Activate() - Peer {peer.ID}");

                lobby?.Activate();
                game?.Activate();

                if (SceneManager.GetSceneByName(_LoadingScene).IsValid()) {
                    yield return new WaitForSeconds(1f);

                    Log($"Hide loading scene");

                    yield return ShowLoadingSceneCoroutine(false);
                }

                peer.WasConnected = true;
                success           = true;

                Log($"ConnectPeerCoroutine() finished.");
            } finally {
                bool userCancelled = _CurrentSession == null || !_CurrentSession.ConnectionRequested;

                if (!success && !userCancelled) {
                    if (peer.WasConnected)
                        peer.ReconnectionTries--;
                    else
                        peer.ConnectionTries--;
                }

                _Coroutine = null;
            }
        }

        private IEnumerator DisconnectPeerCoroutine(GamePeer peer)
        {
            StatusDescription = "disconnect_server";

            try {
                if (peer.Runner != null) {
                    if (peer.Runner.IsServer && peer.Runner.SessionInfo != null) {
                        Log($"Closing the room.");

                        peer.Runner.SessionInfo.IsOpen    = false;
                        peer.Runner.SessionInfo.IsVisible = false;
                    }
                }
            } catch (Exception exception) {
                Debug.LogException(exception);
            }

            List<UnityScene> scenesToUnload = GetScenesToUnload();

            foreach (UnityScene s in scenesToUnload) {
                Scene currentScene = s.GetComponent<Scene>();

                if (currentScene != null) {
                    Log($"Deinitializing Scene.");

                    currentScene.Deinitialize();
                }

                yield return null;
            }
            Task shutdownTask = null;

            if (peer.Runner != null) {
                Debug.LogWarning($"Shutdown {peer.Runner.name} ...");

                try {
                    shutdownTask = peer.Runner.Shutdown(true);
                } catch (Exception exception) {
                    Debug.LogException(exception);
                }
            }
            Log($"Show loading scene.");

            yield return ShowLoadingSceneCoroutine(true);

            if (shutdownTask != null) {
                for (float operationTimeout = 10.0f; operationTimeout > 0.0f && !shutdownTask.IsCompleted; operationTimeout -= Time.unscaledDeltaTime)
                    yield return null;
            }
            StatusDescription = "unloading_gameplay_scene";

            yield return null;

            PersistentSceneService.Instance.SwitchToScene(PersistentSceneService.Instance.PersistentScenes[0]);

            foreach (UnityScene s in scenesToUnload) {
                Debug.LogWarning($"Unloading scene {s.name}");

                yield return SceneManager.UnloadSceneAsync(s.name);
                yield return null;
            }

            peer.Loaded       = default;
            peer.Runner       = default;
            peer.SceneManager = default;
            peer.LoadedScene  = default;

            _Coroutine = null;

            Log($"DisconnectPeerCoroutine() finished.");
        }

        #endregion

        public IEnumerator ApplySceneChangeLocalCoroutine(string peerID, string scenePath, string oldScene, bool isCustom, bool isGameSession, GameplayType gameplayType, string data, System.Action onComplete = null)
        {
            GamePeer peer = GetGamePeer(peerID);

            _IsChangeScene = true;

            yield return ShowLoadingSceneCoroutine(true);

            Log($"Show loading scene.");

            List<UnityScene> scenesToUnload = GetScenesToUnload();

            foreach (var s in scenesToUnload) {
                if (s.name == scenePath || s.name == oldScene)
                    continue;
                Scene currentScene = s.GetComponent<Scene>();

                if (currentScene != null) {
                    Log($"Deinitializing Scene.");

                    currentScene.Deinitialize();
                }
                Log($"Unloading scene {s.name}");

                yield return PersistentSceneService.Instance.UnloadScene(s.name);
                yield return null;
            }

            UnityScene newScene = SceneManager.GetSceneByName(scenePath);
            float       timeout = Time.realtimeSinceStartup + 30f;

            while (!newScene.IsValid() || !newScene.isLoaded) {
                newScene = SceneManager.GetSceneByName(scenePath);

                if (Time.realtimeSinceStartup >= timeout) {
                    Debug.LogError($"Timeout waiting for scene {scenePath} to be loaded.");

                    yield break;
                }

                yield return null;
            }

            Scene scene = newScene.GetComponent<Scene>(true);

            scene.PrepareContext();

            SceneContext context = scene.Context;

            peer.NetworkPool.Context = context;

            context.IsVisible  = true;
            context.HasInput   = true;
            context.Runner     = peer.Runner;
            context.PeerUserID = peerID;

            ContextBehaviour networkManager = null;

            if (isGameSession)
                networkManager = scene.GetComponentInChildren<NetworkGame>(true);
            else
                networkManager = scene.GetComponentInChildren<NetworkLobby>(true);
            while (networkManager.Object == null) {
                Log($"Waiting for NetworkGame");

                yield return null;
            }

            NetworkLobby lobby = null;
            NetworkGame  game  = null;

            if (networkManager is NetworkLobby nl) {
                nl.Initialize();

                lobby = nl;

                while (scene.Context.Lobby == null) {
                    Log($"Waiting for LobbyManager");

                    yield return null;
                }
            } else if (networkManager is NetworkGame ng) {
                ng.Initialize(gameplayType, data);

                game = ng;

                while (scene.Context.GameplayMode == null) {
                    UnityScene persistent = PersistentSceneService.Instance.GetFirstPersistentScene();

                    scene.Context.GameplayMode = persistent.GetComponent<GameplayMode>();

                    Log($"Waiting for GameplayMode");

                    yield return null;
                }
            }

            scene.Initialize();

            yield return scene.Activate();

            lobby?.Activate();
            game?.Activate();

            yield return ShowLoadingSceneCoroutine(false);

            onComplete?.Invoke();

            _IsChangeScene = false;

            yield break;
        }

        private IEnumerator EnterMatchmakingSearchCoroutine(string scenePath)
        {
            Status            = "matchmaking";
            StatusDescription = "loading_matchmaking_scene";

            yield return ShowLoadingSceneCoroutine(true);

            List<UnityScene> scenesToUnload = GetScenesToUnload();

            foreach (UnityScene s in scenesToUnload) {
                Scene currentScene = s.GetComponent<Scene>();

                if (currentScene != null) {
                    Log($"Deinitializing Scene.");

                    currentScene.Deinitialize();
                }

                Log($"Unloading scene {s.name}");

                yield return PersistentSceneService.Instance.UnloadScene(s.name);
                yield return null;
            }

            yield return PersistentSceneService.Instance.LoadSceneAdditive(scenePath);

            UnityScene newScene = SceneManager.GetSceneByName(scenePath);
            float       timeout = Time.realtimeSinceStartup + 30f;

            while (!newScene.IsValid() || !newScene.isLoaded) {
                newScene = SceneManager.GetSceneByName(scenePath);

                if (Time.realtimeSinceStartup >= timeout) {
                    Debug.LogError($"Timeout waiting for scene {scenePath} to be loaded.");

                    _Coroutine = null;

                    yield return LoadMenuCoroutine();
                    yield break;
                }

                yield return null;
            }

            PersistentSceneService.Instance.SwitchToScene(scenePath);

            NetworkObject[] networkObjects = FindObjectsByType<NetworkObject>(FindObjectsInactive.Include, FindObjectsSortMode.None);

            for (int i = 0; i < networkObjects.Length; i++) {
                if (networkObjects[i] != null)
                    Destroy(networkObjects[i].gameObject);
            }

            Scene scene = newScene.GetComponent<Scene>(true);

            if (scene == null) {
                Debug.LogError($"Scene component missing on {scenePath}.");

                _Coroutine = null;

                yield return LoadMenuCoroutine();
                yield break;
            }

            scene.PrepareContext();

            SceneContext context = scene.Context;

            context.IsVisible  = true;
            context.HasInput   = true;
            context.Runner     = null;
            context.PeerUserID = Global.PlayerService.PlayerData.UserID;

            scene.Initialize();

            yield return scene.Activate();
            yield return ShowLoadingSceneCoroutine(false);

            Status            = string.Empty;
            StatusDescription = string.Empty;
            _Coroutine        = null;

            Log($"EnterMatchmakingSearchCoroutine() finished.");
        }

        /// <summary>
        /// True = the session asked to come back to the main menu instead of the tavern (SessionRequest.ReturnToMainMenu).
        /// </summary>
        private static bool ReturnsToMainMenu(Session session)
        {
            if (session?.GamePeers == null || session.GamePeers.Length == 0 || session.GamePeers[0] == null)
                return false;
            return session.GamePeers[0].Request.ReturnToMainMenu;
        }

        /// <summary>
        /// Unloads the gameplay scenes and loads the menu, opened in the tavern unless toMainMenu is true.
        /// </summary>
        private IEnumerator LoadMenuCoroutine(bool toMainMenu = false)
        {
            string menuSceneName = Global.Settings.MenuScene;

            if (SceneManager.sceneCount == 1 && SceneManager.GetSceneAt(0).name == menuSceneName) {
                _Coroutine = null;

                yield break;
            }
            StatusDescription = "unloading_gameplay_scene";

            yield return ShowLoadingSceneCoroutine(true);

            for (int i = SceneManager.sceneCount - 1; i >= 0; i--) {
                var scene = SceneManager.GetSceneAt(i);

                if (scene.name != _LoadingScene)
                    yield return PersistentSceneService.Instance.UnloadScene(scene.name);
            }
            StatusDescription = "loading_menu_scene";

            yield return null;
            yield return PersistentSceneService.Instance.LoadSceneAdditive(menuSceneName);
            yield return ShowLoadingSceneCoroutine(false);

            if (!toMainMenu)
                FindFirstObjectByType<UIMainMenuView>().GoDirectlyToTavern();
            _Coroutine = null;
        }

        public IEnumerator ShowLoadingSceneCoroutine(bool show, float additionalTime = 1f)
        {
            UnityScene loadingScene = SceneManager.GetSceneByName(_LoadingScene);

            if (!loadingScene.IsValid()) {
                yield return PersistentSceneService.Instance.LoadSceneAdditive(_LoadingScene);

                loadingScene = SceneManager.GetSceneByName(_LoadingScene);
            }
            
            if (!show && additionalTime > 0f)
                yield return new WaitForSeconds(additionalTime); // Wait additional time till fade out start.
            yield return null;

            LoadingScene loadingSceneObject = loadingScene.GetComponent<LoadingScene>();

            if (loadingSceneObject != null) {
                if (show)
                    loadingSceneObject.FadeIn();
                else
                    loadingSceneObject.FadeOut();
                while (loadingSceneObject.IsFading)
                    yield return null;
            }

            if (show && additionalTime > 0f)
                yield return new WaitForSeconds(additionalTime); // Wait additional time after fade in.
            if (!show)
                yield return PersistentSceneService.Instance.UnloadScene(loadingScene.name);
        }

        #endregion

        #region Utils

        public List<UnityScene> GetScenesToUnload()
        {
            int sceneCount = SceneManager.sceneCount;
            List<UnityScene> scenesToUnload = new(sceneCount);

            for (int i = 0; i < sceneCount; i++) {
                UnityScene s = SceneManager.GetSceneAt(i);

                if (s.name == _LoadingScene || PersistentSceneService.Instance.IsScenePersistent(s.name))
                    continue;
                scenesToUnload.Add(s);
            }

            return scenesToUnload;
        }

        public GamePeer GetPeer(NetworkRunner runner)
        {
            if (_CurrentSession == null)
                return null;
            foreach (GamePeer peer in _CurrentSession.GamePeers) {
                if (peer.Runner == runner)
                    return peer;
            }

            return null;
        }

        private Dictionary<string, SessionProperty> CreateSessionProperties(SessionRequest request)
        {
            return new Dictionary<string, SessionProperty> {
                [TYPE_KEY]     = (int)request.GameplayType,
                [MODE_KEY]     = (int)request.GameMode,
                [CUSTOM_KEY]   =      request.IsCustom,
                [GAME_SESSION] =      request.IsGameSession
            };
        }

        private static string StringToLabel(string str)
        {
            var label = System.Text.RegularExpressions.Regex.Replace(str, "(?<=[A-Z@])(?=[A-Z][a-z])", " ");

            label = System.Text.RegularExpressions.Regex.Replace(label, "(?<=[^A-Z])(?=[A-Z])", " ");

            return label;
        }

        #endregion

        #region Comparator

        public GamePeer GetGamePeer(string peerUserId)
        {
            if (_CurrentSession == null)
                return default;
            return _CurrentSession.GamePeers.Find(peer => peer.UserID == peerUserId);
        }

        private static bool IsSceneLoaded(string sceneToCheck)
        {
            bool alreadyLoaded = false;

            for (int i = 0; i < SceneManager.sceneCount; i++) {
                UnityScene scene = SceneManager.GetSceneAt(i);

                if (IsSameScene(scene.path, sceneToCheck)) {
                    alreadyLoaded = true;

                    break;
                }
            }

            return alreadyLoaded;
        }

        private static bool IsSameScene(string assetPath, string scenePath)
        {
            return assetPath == $"Assets/{scenePath}.unity";
        }

        #endregion

        #region Logs

        [System.Diagnostics.Conditional("ENABLE_LOGS")]
        private void Log(string message)
        {
            Debug.Log($"[{Time.realtimeSinceStartup:F3}][{Time.frameCount}] Networking({GetInstanceID()}: {message}");
        }

        #endregion
    }
}
