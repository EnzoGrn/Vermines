using Fusion;
using OMGG.DesignPattern;
using System.Collections.Generic;
using UnityEngine;

namespace Vermines.Gameplay.Phases {

    using Vermines.CardSystem.Data.Effect;
    using Vermines.CardSystem.Elements;
    using Vermines.Gameplay.Cards.Effect;
    using Vermines.Gameplay.Commands.Cards.Effects;
    using Vermines.Player;
    using Vermines.UI;
    using Vermines.UI.Screen;
    using Vermines.CardSystem.Enumerations;
    using Vermines.Gameplay.Phases.Data;
    using System.Linq;

    [CreateAssetMenu(menuName = "Vermines/Phases/GainPhase")]
    public class GainPhaseAsset : PhaseAsset {

        #region Attributes

        public int EloquenceToEarn = 2;

        private GainSummaryData _gainSummary;

        private bool isFirstTurn = true;

        #endregion

        #region Override Methods

        public override void Run(PlayerRef playerRef)
        {
            if (_Context.GameplayMode.State != Vermines.Core.GameplayMode.GState.Active)
                return;

            base.Run(playerRef);

            PlayerController player = _Context.NetworkGame.GetPlayer(playerRef);

            if (isFirstTurn)
            {
                List<PlayerController> players = _Context.Runner.GetAllBehaviours<PlayerController>();

                foreach (var p in players)
                {
                    foreach (var effect in p.God.Effects)
                    {
                        if ((effect.Type & EffectType.OnGameStart) != 0)
                            effect.Play(p.Object.InputAuthority);
                    }
                }

                isFirstTurn = false;
            }

            ExecuteCardEffect(player);

            _gainSummary.BaseValue = EloquenceToEarn;
            _gainSummary.FollowerValue = CalculateFollowerBonus(player.PlayedCards.ToList());

            ICommand earnCommand = new EarnCommand(player, _gainSummary.BaseValue, DataType.Eloquence);

            CommandInvoker.ExecuteCommand(earnCommand);

            GameEvents.OnPlayerUpdated.Invoke(player);

            if (_CurrentPlayer == _Context.Runner.LocalPlayer)
            {
                GameEvents.OnGainPhaseResolved.Invoke(_CurrentPlayer, _gainSummary);
            }
        }

        #endregion

        #region Methods

        private int CalculateFollowerBonus(List<ICard> deck)
        {
            int total = 0;

            foreach (ICard card in deck) {
                foreach (IEffect effect in card.Data.Effects) {
                    if ((effect.Type & EffectType.Play) != 0 && effect.SubEffect != null && effect.SubEffect is EarnEffect eloquenceBonus && eloquenceBonus.DataToEarn == DataType.Eloquence)
                        total += eloquenceBonus.Amount;
                }
            }

            return total;
        }

        private void ExecuteCardEffect(PlayerController player)
        {
            List<ICard> equipmentCards = player.Equipments.ToList();
            List<ICard> playedCards    = player.PlayedCards.ToList();

            foreach (ICard card in equipmentCards) {
                foreach (IEffect effect in card.Data.Effects) {
                    if ((effect.Type & EffectType.Play) != 0)
                        effect.Play(_CurrentPlayer);
                }
            }

            foreach (ICard card in playedCards) {
                foreach (IEffect effect in card.Data.Effects) {
                    if ((effect.Type & EffectType.Passive) != 0)
                        effect.Play(_CurrentPlayer);
                }
            }

            foreach (ICard card in playedCards) {
                foreach (AEffect effect in card.Data.Effects) {
                    if ((effect.Type & EffectType.Play) != 0)
                        effect.Play(_CurrentPlayer);
                }
            }
        }

        #endregion
    }
}
