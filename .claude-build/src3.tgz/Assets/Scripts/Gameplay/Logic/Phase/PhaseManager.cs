using Fusion;
using OMGG.Network.Fusion;
using System.Collections.Generic;
using UnityEngine;
using System.Collections;
using System.Linq;

namespace Vermines.Gameplay.Phases
{

    using Vermines.CardSystem.Elements;
    using Vermines.CardSystem.Enumerations;
    using Vermines.Core;
    using Vermines.Gameplay.Phases.Enumerations;
    using Vermines.Tutorial.Integration;
    using Vermines.Player;
    using Vermines.UI;
    using Vermines.UI.Screen;

    [System.Serializable]
    public class PhaseEntry
    {
        public PhaseType phaseType;
        public PhaseAsset phaseAsset;
    }

    public class PhaseManager : ContextBehaviour
    {

        #region Phases

        private List<PhaseType> _PhaseOrder;

        [Networked]
        public PhaseType CurrentPhase { get; set; } = PhaseType.None;

        [SerializeField]
        private List<PhaseEntry> phaseEntries;

        private Dictionary<PhaseType, PhaseAsset> _Phases;
        public Dictionary<PhaseType, PhaseAsset> Phases => _Phases;

        private TurnTimer _TurnTimer;

        /// <summary>
        /// True once the game intro was played (before the first turn only).
        /// </summary>
        private bool _IntroPlayed;

        #endregion

        [SerializeField]
        private PUI_GameIntro _UIIntro_Prefab;

        #region Network Methods

        public override void Despawned(NetworkRunner runner, bool hasState)
        {
            Deinitialize();

            base.Despawned(runner, hasState);
        }

        #endregion

        #region Methods

        public void Initialize()
        {
            _TurnTimer = GetComponent<TurnTimer>();
            SetUpPhases();
            SetUpUI();
            SetUpEvents();

            GameEvents.OnGameInitialized.AddListenerAndReplay(OnGameStart);
        }

        public void Deinitialize()
        {
            GameEvents.OnAttemptNextPhase.RemoveListener(OnPhaseCompleted);

            if (_Phases != null) {
                foreach (var kvp in _Phases)
                    kvp.Value.Deinitialize();
            }
        }

        private void SetUpPhases()
        {
            _Phases = new();
            _PhaseOrder = new();

            foreach (var entry in phaseEntries) {
                entry.phaseAsset.Initialize(Context, this);

                _Phases[entry.phaseType] = entry.phaseAsset;
                _PhaseOrder.Add(entry.phaseType);
            }
        }

        public void OnGameStart()
        {
            CurrentPhase = _PhaseOrder[0];

            if (HasStateAuthority)
            {
                RPC_TurnAnnounced();
            }

            GameEvents.OnGameInitialized.RemoveListener(OnGameStart);
        }

        private void SetUpUI()
        {
            GameEvents.OnPlayerInitialized.Invoke();
        }

        private void SetUpEvents()
        {
            GameEvents.OnAttemptNextPhase.AddListener(OnPhaseCompleted);
        }

        private PhaseType GetNextPhase()
        {
            int index = _PhaseOrder.IndexOf(CurrentPhase);

            if (index == -1 || index + 1 >= _PhaseOrder.Count)
                return _PhaseOrder[0];
            return _PhaseOrder[index + 1];
        }

        #endregion

        public void NextTurn()
        {
            RPC_ResetCardActivations();

            if (Runner.IsServer && _TurnTimer != null)
                _TurnTimer.Stop();

            if (!Runner.IsServer)
                return;
            CurrentPhase = _PhaseOrder[0];

            Context.GameplayMode.CurrentPlayerIndex = (Context.GameplayMode.CurrentPlayerIndex + 1) % Context.GameplayMode.TurnPlayerCount;

            if (Context.GameplayMode.CurrentPlayerIndex == 0)
                Context.GameplayMode.TotalTurnPlayed++;
            RPC_UpdateTurnUI();
        }

        private IEnumerator SacrificeRoutine()
        {
            GameplayUIController gameplayUIController = GameObject.FindAnyObjectByType<GameplayUIController>(FindObjectsInactive.Include);

            // Actively wait (bounded) for PlayerController.Local before showing the
            // turn banner - without this, GameplayUITurn.Show() could fire before
            // it's ready and just skip displaying the banner (see its own defensive
            // guard) instead of actually showing it.
            float waitElapsed = 0f;
            const float waitTimeout = 5f;

            while (!PlayerController.Local && waitElapsed < waitTimeout)
            {
                yield return null;
                waitElapsed += Time.unscaledDeltaTime;
            }

            if (!PlayerController.Local)
                Debug.LogWarning("[PhaseManager] SacrificeRoutine: PlayerController.Local never became ready within timeout - turn banner may not display correctly this time.");

            // Before the first turn: intro with every player, their cultist and their god.
            // The host waits for the whole intro even if skipped, so the first turn starts at the same moment for everyone.
            if (!_IntroPlayed) {
                _IntroPlayed = true;

                if (!TutorialMatch.IsActive || TutorialMatch.Setup.ShowGameIntro)
                    yield return PUI_GameIntro.PlayForGame(Context.GameplayMode, Context.NetworkGame, Runner.LocalPlayer, _UIIntro_Prefab, Runner.IsServer);
                PUI_GameIntro.MarkFinished();
            }

            if (gameplayUIController != null)
                gameplayUIController.Show<GameplayUITurn>();

            yield return new WaitForSeconds(3f);

            if (gameplayUIController != null &&
                gameplayUIController.GetActiveScreen(out GameplayUIScreen activeScreen) &&
                activeScreen is GameplayUITurn)
            {
                gameplayUIController.Hide();
            }

            if (!Runner.IsServer)
                yield break;
            if (_TurnTimer != null)
                _TurnTimer.Begin();
            RPC_ProcessPhase(CurrentPhase, Context.GameplayMode.PlayerTurnOrder.Get(Context.GameplayMode.CurrentPlayerIndex));
        }

        private void ResetCardActivations()
        {
            PlayerRef playerRef = Context.GameplayMode.PlayerTurnOrder.Get(Context.GameplayMode.CurrentPlayerIndex);

            foreach (ICard card in Context.NetworkGame.GetPlayer(playerRef).PlayedCards)
                card.HasBeenActivatedThisTurn = false;
        }

        /// <summary>
        /// Raised on every peer when a phase starts running for a player.
        /// </summary>
        public static event System.Action<PhaseType, PlayerRef> PhaseProcessed;

        public void ProcessPhase(PhaseType currentPhase, PlayerRef playerRef)
        {
            if (currentPhase == PhaseType.None || !playerRef.IsRealPlayer)
                return;
            PhaseProcessed?.Invoke(currentPhase, playerRef);

            _Phases[currentPhase].Run(playerRef);
        }

        public void PhaseCompleted()
        {
            if (!Runner.IsServer)
                return;
            // Check if the player did every phases.
            if (CurrentPhase == PhaseType.Resolution) {
                NextTurn();

                RPC_TurnAnnounced();
            } else {
                CurrentPhase = GetNextPhase();

                RPC_UpdatePhaseUI();
                RPC_ProcessPhase(CurrentPhase, Context.GameplayMode.PlayerTurnOrder.Get(Context.GameplayMode.CurrentPlayerIndex));
            }
        }

        /// <summary>
        /// Server only. Called by the turn timer: jumps straight to the
        /// Resolution phase so the turn still ends the normal way (end-of-turn
        /// draw, effect cleanup, next player).
        /// </summary>
        public void ForceEndTurn()
        {
            if (!Runner.IsServer)
                return;
            // Resolution is instantaneous: if we are already there, the turn is ending.
            if (CurrentPhase == PhaseType.None || CurrentPhase == PhaseType.Resolution)
                return;

            PlayerRef current = Context.GameplayMode.PlayerTurnOrder.Get(Context.GameplayMode.CurrentPlayerIndex);

            CurrentPhase = PhaseType.Resolution;

            RPC_TurnTimeExpired();

            PlayerController player = Context.NetworkGame.GetPlayer(current);

            if (player != null)
            {
                foreach (ICard card in player.Hand.ToList())
                {
                    if (card.Data.CanBeDiscard())
                        player.RPC_DiscardCard(card.ID, false);
                }
            }

            RPC_UpdatePhaseUI();
            RPC_ProcessPhase(CurrentPhase, current);
        }


        #region RPC

        [Rpc(sources: RpcSources.StateAuthority, targets: RpcTargets.All)]
        public void RPC_UpdatePhaseUI()
        {
            GameEvents.OnPhaseChanged.Invoke(CurrentPhase);
        }

        [Rpc(sources: RpcSources.StateAuthority, targets: RpcTargets.All)]
        public void RPC_UpdateTurnUI()
        {
            GameEvents.OnTurnChanged.Invoke(Context.GameplayMode.CurrentPlayerIndex);
            GameEvents.OnPhaseChanged.Invoke(CurrentPhase);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="currentPhase">The currentPhase may intefer since it is a network variable, this argument avoid desync between clients</param>
        [Rpc(sources: RpcSources.StateAuthority, targets: RpcTargets.All)]
        public void RPC_ProcessPhase(PhaseType currentPhase, PlayerRef playeRef)
        {
            ProcessPhase(currentPhase, playeRef);
        }

        [Rpc(sources: RpcSources.All, targets: RpcTargets.All)]
        public void RPC_PhaseCompleted()
        {
            PhaseCompleted();
        }

        [Rpc(sources: RpcSources.StateAuthority, targets: RpcTargets.All)]
        public void RPC_TurnAnnounced()
        {
            StartCoroutine(SacrificeRoutine());
        }

        [Rpc(sources: RpcSources.StateAuthority, targets: RpcTargets.All)]
        public void RPC_ResetCardActivations()
        {
            ResetCardActivations();
        }

        [Rpc(sources: RpcSources.StateAuthority, targets: RpcTargets.All)]
        public void RPC_TurnTimeExpired()
        {
            // The interrupted phase never reaches OnPhaseEnding: reset it here.
            foreach (var phase in _Phases)
            {
                if (phase.Key != PhaseType.Resolution)
                    phase.Value.Deinitialize();
            }

            GameEvents.OnTurnTimerExpired.Invoke();
        }

        #endregion

        #region Events

        public void OnStartPhases()
        {
            if (!Runner.IsServer || Context.GameplayMode.State != GameplayMode.GState.Active)
                return;
            List<PlayerController> players = Context.Runner.GetAllBehaviours<PlayerController>();

            foreach (var player in players)
                GameEvents.OnPlayerUpdated.Invoke(player);
            RPC_TurnAnnounced();
        }

        public void OnPhaseCompleted()
        {
            RPC_PhaseCompleted();
        }

        #endregion
    }
}
