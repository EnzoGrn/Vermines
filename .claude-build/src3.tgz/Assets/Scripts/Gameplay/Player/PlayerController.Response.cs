using Fusion;
using OMGG.Chronicle;
using OMGG.DesignPattern;
using UnityEngine;

namespace Vermines.Player {

    using Vermines.CardSystem.Data;
    using Vermines.CardSystem.Data.Effect;
    using Vermines.CardSystem.Elements;
    using Vermines.CardSystem.Enumerations;
    using Vermines.Core;
    using Vermines.Core.Player;
    using Vermines.Gameplay.Cards.Effect;
    using Vermines.Gameplay.Commands;
    using Vermines.Gameplay.Errors;
    using Vermines.ShopSystem;
    using Vermines.ShopSystem.Commands;
    using Vermines.ShopSystem.Data;
    using Vermines.ShopSystem.Enumerations;
    using Vermines.UI;
    using Vermines.UI.Card;
    using Vermines.UI.Screen;

    public partial class PlayerController : ContextBehaviour, IPlayer {

        #region Shop

        [Rpc(RpcSources.StateAuthority, RpcTargets.All)]
        public void RPC_BuyCard(NetworkChronicleEntry nEntry, ShopType sType, int cardId)
        {
            // The state authority already process the command on his side. So ignore it.
            if (!HasStateAuthority) {
                ShopArgs parameters = new(Context.GameplayMode.Shop, sType, cardId);
                ICommand buyCommand = new CLIENT_BuyCommand(this, parameters);

                CommandInvoker.ExecuteCommand(buyCommand);
            }

            GameEvents.OnCardPurchased.Invoke(sType, cardId);

            AddChronicle(nEntry.ToChronicleEntry());
        }

        [Rpc(RpcSources.StateAuthority, RpcTargets.All)]
        public void RPC_AddCardInCourtyard(NetworkChronicleEntry nEntry, int level)
        {
            ShopData              shop = Context.GameplayMode.Shop;
            CourtyardSection courtyard = shop.Sections[ShopType.Courtyard] as CourtyardSection;

            courtyard.AddCard(level);

            GameEvents.OnShopRefilled.Invoke(ShopType.Courtyard, shop.GetDisplayCards(ShopType.Courtyard));

            foreach (var card in PlayedCards) {
                if (card.Data.Effects != null) {
                    foreach (var effect in card.Data.Effects) {
                        if ((effect.Type & EffectType.OnCardAddedToCourtyard) != 0)
                            effect.Play(Object.InputAuthority);
                    }
                }
            }

            AddChronicle(nEntry.ToChronicleEntry());
        }

        #endregion

        #region Sacrifice

        [Rpc(RpcSources.StateAuthority, RpcTargets.All)]
        public void RPC_CardSacrified(NetworkChronicleEntry nEntry, int cardId)
        {
            ICard card = CardSetDatabase.Instance.GetCardByID(cardId);

            if (!HasStateAuthority) {
                ICommand cardSacrifiedCommand = new CLIENT_CardSacrifiedCommand(this, cardId);

                CommandInvoker.ExecuteCommand(cardSacrifiedCommand);

                foreach (AEffect effect in card.Data.Effects) {
                    if ((effect.Type & EffectType.Sacrifice) != 0)
                        effect.Play(Object.InputAuthority);
                    else if ((effect.Type & EffectType.Passive) != 0)
                        effect.Stop(Object.InputAuthority);
                }

                foreach (ICard playedCard in PlayedCards) {
                    if (playedCard == card)
                        continue;
                    if (playedCard.Data.Effects != null) {
                        foreach (AEffect effect in playedCard.Data.Effects) {
                            if ((effect.Type & EffectType.OnOtherSacrifice) != 0)
                                effect.Play(Object.InputAuthority);
                        }
                    }
                }

                if (God.Effects != null) {
                    foreach (var effect in God.Effects) {
                        if ((effect.Type & EffectType.OnOtherSacrifice) != 0)
                            effect.Play(Object.InputAuthority);
                    }
                }
            }

            GameEvents.OnCardSacrificed.Invoke(card);

            AddChronicle(nEntry.ToChronicleEntry());
        }

        #endregion

        #region Recycle

        [Rpc(RpcSources.StateAuthority, RpcTargets.All)]
        public void RPC_CardRecycled(NetworkChronicleEntry nEntry, int cardId)
        {
            ICard card = CardSetDatabase.Instance.GetCardByID(cardId);

            if (!HasStateAuthority) {
                ICommand cardSacrifiedCommand = new CLIENT_CardRecycleCommand(this, cardId, Context.GameplayMode.Shop.Sections[ShopType.Market]);

                CommandInvoker.ExecuteCommand(cardSacrifiedCommand);
            }

            foreach (AEffect effect in card.Data.Effects) {
                if ((effect.Type & EffectType.Recycle) != 0)
                    effect.Play(Object.InputAuthority);
            }

            foreach (ICard playedCard in PlayedCards) {
                if (playedCard == card)
                    continue;
                if (playedCard.Data.Effects != null) {
                    foreach (AEffect effect in playedCard.Data.Effects) {
                        if ((effect.Type & EffectType.OnOtherRecycle) != 0)
                            effect.Play(Object.InputAuthority);
                    }
                }
            }

            GameEvents.OnCardRecycled.Invoke(card);

            AddChronicle(nEntry.ToChronicleEntry());
        }

        #endregion

        [Rpc(RpcSources.StateAuthority, RpcTargets.All)]
        public void RPC_DiscardCard(int cardId, bool hasEffect = true)
        {
            ICommand discardCommand = new CLIENT_DiscardCommand(this, cardId);

            CommandInvoker.ExecuteCommand(discardCommand);

            ICard card = CardSetDatabase.Instance.GetCardByID(cardId);

            GameEvents.OnPlayerUpdated.Invoke(this);

            Context.HandManager.RemoveCard(card);

            if (!hasEffect) {
                if (Object.InputAuthority == Context.Runner.LocalPlayer) {
                    DiscardDropHandler discardDropHandler = DiscardDrop;

                    if (discardDropHandler != null)
                        discardDropHandler.SetLatestDiscardedCard(card);
                }

                return;
            }

            foreach (ICard playedCard in PlayedCards) {
                if (playedCard == card)
                    continue;
                if (playedCard.Data.Effects != null) {
                    foreach (AEffect effect in playedCard.Data.Effects) {
                        if ((effect.Type & EffectType.OnOtherDiscard) != 0 && effect is OtherDiscardEffect discard) {
                            if (discard.TargetType == card.Data.Type || discard.TargetType == CardType.None)
                                effect.Play(Object.InputAuthority);
                        }
                    }
                }
            }

            if (God.Effects != null) {
                foreach (var effect in God.Effects) {
                    if ((effect.Type & EffectType.OnOtherDiscard) != 0 && effect is OtherDiscardEffect discard) {
                        if (discard.TargetType == card.Data.Type || discard.TargetType == CardType.None)
                            effect.Play(Object.InputAuthority);
                    }
                }
            }

            if (card.Data.HasChoiceEffect(EffectType.Discard)) {
                if (Object.InputAuthority == Context.Runner.LocalPlayer) {
                    GameplayUIController uiController = GameplayUI;

                    // Remembers the open screen (the table when the card was dropped on the discard),
                    // so it comes back once the chosen effect, and the prompts it opens, are done.
                    if (uiController != null) {
                        uiController.GetActiveScreen(out GameplayUIScreen origin);
                        uiController.ShowWithParams<GameplayUIChoiceEffect, ICard>(card, origin is GameplayUIChoiceEffect ? null : origin);
                    }
                }
            } else {
                foreach (AEffect effect in card.Data.Effects) {
                    if ((effect.Type & EffectType.Discard) != 0)
                        effect.Play(Object.InputAuthority);
                }
            }
            // Lets a pending forced-discard effect (DiscardCardEffect) continue.
            if (Object.InputAuthority == Context.Runner.LocalPlayer)
                GameEvents.OnCardDiscarded.Invoke(card);
        }

        [Rpc(RpcSources.StateAuthority, RpcTargets.All)]
        public void RPC_CardPlayed(int cardId)
        {
            ICommand cardPlayedCommand = new CLIENT_PlayCommand(this, cardId);

            CommandResponse response = CommandInvoker.ExecuteCommand(cardPlayedCommand);

            ICard card = CardSetDatabase.Instance.GetCardByID(cardId);

            if (response.Status == CommandStatus.Invalid)
            {
                Debug.LogWarning($"[SERVER]: {response.Message}");

                GameActionError localError = new GameActionError
                {
                    Scope = ErrorScope.Local,
                    Target = Object.InputAuthority,
                    Severity = ErrorSeverity.Minor,
                    Location = ErrorLocation.Table,
                    MessageKey = response.Message,
                    MessageArgs = new GameActionErrorArgs(response.Args)
                };

                string localizedMessage = GameActionError.Localize(localError);

                GameEvents.OnActionRefused.Invoke(localError, localizedMessage);
            }
            else if (response.Status == CommandStatus.Success)
            {
                GameEvents.OnCardPlayed.Invoke(card);

                foreach (AEffect effect in card.Data.Effects)
                    effect.OnAction("Play", Object.InputAuthority, card);
            }
        }

        [Rpc(RpcSources.StateAuthority, RpcTargets.All)]
        public void RPC_ActivateEffect(int cardID)
        {
            ICard card = CardSetDatabase.Instance.GetCardByID(cardID);

            foreach (AEffect effect in card.Data.Effects) {
                if ((effect.Type & EffectType.Activate) != 0)
                    effect.Play(Object.InputAuthority);
            }
        }

        [Rpc(RpcSources.StateAuthority, RpcTargets.All)]
        public void RPC_ReducedInSilenced(int cardId)
        {
            ICard card = CardSetDatabase.Instance.GetCardByID(cardId);

            if (card == null) {
                Debug.LogError($"[SERVER]: Player {Object.InputAuthority} tried to reduce in silence a card that doesn't exist.");

                return;
            }

            ICommand command = new ReducedInSilenceCommand(card);

            CommandInvoker.ExecuteCommand(command);

            // TODO: Maybe update the card UI ?
        }

        [Rpc(RpcSources.StateAuthority, RpcTargets.All)]
        public void RPC_RemoveReducedInSilenced(int cardID, int originalSouls)
        {
            ICard card = CardSetDatabase.Instance.GetCardByID(cardID);

            if (card == null) {
                Debug.LogError($"[SERVER]: Player {Object.InputAuthority} tried to remove the reduction in silence of a card that doesn't exist.");

                return;
            }

            ICommand command = new RemoveReducedInSilenceCommand(card, originalSouls);

            CommandInvoker.ExecuteCommand(command);

            // TODO: Maybe update the card UI ?
        }

        [Rpc(RpcSources.StateAuthority, RpcTargets.All)]
        public void RPC_CopiedEffect(NetworkChronicleEntry nEntry, int cardID, int cardToCopiedID)
        {
            ICard card         = CardSetDatabase.Instance.GetCardByID(cardID);
            ICard cardToCopied = CardSetDatabase.Instance.GetCardByID(cardToCopiedID);

            if (card == null || cardToCopied == null) {
                Debug.LogError($"[SERVER]: Player {Object.InputAuthority} tried to copy an effect of a card that doesn't exist.");

                return;
            }

            card.Data.CopyEffect(cardToCopied.Data.Effects);

            foreach (AEffect effect in card.Data.Effects) {
                if ((effect.Type & EffectType.Sacrifice) != 0 || (effect.Type & EffectType.OnOtherSacrifice) != 0)
                    return;
                effect.Play(Object.InputAuthority);
            }

            AddChronicle(nEntry.ToChronicleEntry());
        }

        [Rpc(RpcSources.StateAuthority, RpcTargets.All)]
        public void RPC_RemoveCopiedEffect(int cardID)
        {
            ICard card = CardSetDatabase.Instance.GetCardByID(cardID);

            if (card == null) {
                Debug.LogError($"[SERVER]: Player {Object.InputAuthority} tried to removed a copied effect of a card that doesn't exist.");

                return;
            }

            card.Data.RemoveEffectCopied();

            // TODO: Maybe update the card UI, of the card (effect)
        }

        [Rpc(RpcSources.StateAuthority, RpcTargets.All)]
        public void RPC_NetworkEventCardEffect(int cardID, string data)
        {
            if (cardID == -1) {
                foreach (AEffect effect in God.Effects)
                    effect.NetworkEventFunction(Object.InputAuthority, data);
            } else {
                ICard card = CardSetDatabase.Instance.GetCardByID(cardID);

                foreach (AEffect effect in card.Data.Effects)
                    effect.NetworkEventFunction(Object.InputAuthority, data);
            }
        }

        [Rpc(RpcSources.StateAuthority, RpcTargets.All)]
        public void RPC_EffectChosen(int cardId, int effectIndex)
        {
            ICard card = CardSetDatabase.Instance.GetCardByID(cardId);

            if (Object.InputAuthority == Context.Runner.LocalPlayer) {
                GameplayUIController uiController = GameplayUI;

                if (uiController != null)
                    uiController.Hide<GameplayUIChoiceEffect>();
            }
            card.Data.Effects[effectIndex].Play(Object.InputAuthority);
        }
    }
}
