using System.Collections.Generic;
using Newtonsoft.Json;
using OMGG.Chronicle;
using UnityEngine;
using System;
using Fusion;

namespace Vermines.Gameplay.Cards.Effect {

    using Vermines.CardSystem.Data;
    using Vermines.CardSystem.Data.Effect;
    using Vermines.CardSystem.Elements;
    using Vermines.CardSystem.Enumerations;
    using Vermines.Gameplay.Chronicle;
    using Vermines.Player;

    [CreateAssetMenu(fileName = "New Effect", menuName = "Vermines/Card System/Card/Effects/Copy/Copy a partisan effect.")]
    public class CopyPartisanEffect : AEffect {

        #region Constants

        private static readonly string copyTemplate = "Play the effect of a different partisan.";

        #endregion

        #region Properties

        [SerializeField]
        private string _Description;

        public override string Description
        {
            get => _Description;
            set
            {
                _Description = value;
            }
        }

        private ICard _CardCopied = null;

        #endregion

        #region UI Elements

        public Sprite PartisanCardIcon = null;
        public Sprite PartisanEffectIcon = null;

        #endregion

        public override bool CanBePlayed(PlayerRef player, out string reasonKey)
        {
            PlayerController controller = Context.NetworkGame.GetPlayer(player);

            if (EffectCandidates.ForCopyPartisan(Context, CardType.Partisan, Card).Count == 0)
            {
                reasonKey = "skipped.copy_no_target";

                return false;
            }

            return base.CanBePlayed(player, out reasonKey);
        }

        public override void Play(PlayerRef player)
        {
            if (player != Context.Runner.LocalPlayer)
                return;
            if (!CanBePlayed(player, out string reasonKey))
            {
                GameEvents.OnEffectSkipped.Invoke(Card, reasonKey);

                return;
            }
            GameEvents.OnEffectPromptRequested.Invoke(new EffectPrompt(EffectPromptKind.Copy, CardType.Partisan, Card));
            GameEvents.OnEffectSelectCard.AddListener(CopiedEffect);
            GameEvents.OnTurnTimerExpired.AddListener(CancelPrompt);
        }

        public override void Stop(PlayerRef player)
        {
            if (_CardCopied != null) {
                foreach (var effect in _CardCopied.Data.Effects) {
                    if ((effect.Type & EffectType.Passive) != 0)
                        effect.Stop(player);
                }

                Card.Data.RemoveEffectCopied();

                _CardCopied = null;
            }
        }

        private void CopiedEffect(ICard card)
        {
            GameEvents.OnEffectSelectCard.RemoveListener(CopiedEffect);
            GameEvents.OnEffectPromptClosed.Invoke(EffectPromptKind.Copy);
            GameEvents.OnTurnTimerExpired.RemoveListener(CancelPrompt);

            if (card.Data.Type != CardType.Partisan)
                return;
            PlayerController player = Context.NetworkGame.GetPlayer(Context.Runner.LocalPlayer);

            _CardCopied = card;

            RoundEventDispatcher.RegisterEvent(player.Object.InputAuthority, Stop);

            player.NetworkEventCardEffect(Card == null ? -1 : Card.ID, card.ID.ToString());
        }

        private void CancelPrompt()
        {
            GameEvents.OnEffectSelectCard.RemoveListener(CopiedEffect);
            GameEvents.OnTurnTimerExpired.RemoveListener(CancelPrompt);
        }

        public override void NetworkEventFunction(PlayerRef playerRef, string data)
        {
            PlayerController player = Context.NetworkGame.GetPlayer(playerRef);

            ICard card = CardSetDatabase.Instance.GetCardByID(data);

            Card.Data.CopyEffect(card.Data.Effects);

            foreach (var effect in card.Data.Effects) {
                if ((effect.Type & EffectType.Sacrifice) != 0 || (effect.Type & EffectType.OnOtherSacrifice) != 0 || (effect.Type & EffectType.OnOtherDiscard) != 0 || (effect.Type & EffectType.OnCardAddedToCourtyard) != 0)
                    continue;
                effect.Play(playerRef);
            }

            ChronicleEntry entry = new() {
                Id              = $"copied-{Card.ID}-{card.ID}",
                TimestampUtc    = DateTime.UtcNow.Ticks,
                EventType       = new VerminesLogEventType(VerminesLogsType.CopiedEffect),
                TitleKey        = $"T_CardReplaced",
                MessageKey      = $"D_CardReplaced",
                IconKey         = $"Partisan_Card_Effect",
                DescriptionArgs = new string[] {
                    "ST_CardReplaced",
                    player.Nickname,
                    Card.Data.Name,
                    card.Data.Name
                }
            };

            var payloadObject = new {
                DescriptionArgs = entry.DescriptionArgs,
                CardId = Card.ID,
                copiedCardId = card.ID,
                // ...
            };

            string payloadJson = JsonConvert.SerializeObject(payloadObject);

            ChroniclePayloadStorage.Add(entry.Id, payloadJson);

            entry.PayloadJson = payloadJson;

            player.AddChronicle(entry);
        }

        public override List<(string, Sprite)> Draw()
        {
            List<(string, Sprite)> elements = new() {
                { (null, PartisanEffectIcon) },
                { (" != ", null) },
                { (null, PartisanCardIcon) }
            };

            return elements;
        }

        protected override void UpdateDescription()
        {
            Description = copyTemplate;
        }

        private void OnEnable()
        {
            UpdateDescription();

            if (PartisanEffectIcon == null)
                PartisanEffectIcon = Resources.Load<Sprite>("Sprites/UI/Effects/Partisan_Card_Effect");
            if (PartisanCardIcon == null)
                PartisanCardIcon = Resources.Load<Sprite>("Sprites/UI/Effects/Partisan_Card_Played");
        }

        #region Editor Editor

        public override void OnValidate()
        {
            UpdateDescription();
        }

        #endregion
    }
}
