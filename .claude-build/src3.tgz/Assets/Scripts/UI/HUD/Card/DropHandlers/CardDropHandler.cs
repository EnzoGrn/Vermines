using UnityEngine;
using UnityEngine.EventSystems;
using Vermines.CardSystem.Elements;
using Vermines.Gameplay.Cards.Effect;
using Vermines.Gameplay.Errors;
using Vermines.Player;
using Vermines.UI.GameTable;

namespace Vermines.UI.Card
{
    /// <summary>
    /// Handles dropping a card onto a table slot ("playing a card").
    /// Applies an OPTIMISTIC display: the visual change happens immediately on
    /// drop, before server confirmation. If the server refuses, the action is
    /// rolled back visually (see <see cref="OnActionRefused"/>).
    /// </summary>
    public class CardDropHandler : MonoBehaviour, IDropHandler
    {
        protected CardSlotBase slot;

        // Card whose action is currently pending server confirmation/refusal.
        // Null if no action is currently in flight for this slot.
        private ICard _PendingCard;

        #region Unity Lifecycle

        protected virtual void Awake()
        {
            slot = GetComponent<CardSlotBase>();
        }

        protected virtual void OnDestroy()
        {
        }

        #endregion

        #region Local (read-only) prediction checks

        // LOCAL, non-authoritative check: avoids attempting an action we
        // already know will fail (it's not our turn). The server remains the
        // only real source of truth; this check only exists to give the
        // player instant feedback without a network round-trip.
        protected bool IsMyTurn => PlayerController.Local.Context.GameplayMode.IsMyTurn;

        protected bool IsSlotTaken => slot.CardDisplay != null && slot.CardDisplay.gameObject.activeSelf;

        protected bool IsTableFull
        {
            get
            {
                PlayerController player = PlayerController.Local;

                return player != null && player.PlayedCards.Count >= player.Statistics.NumberOfSlotInTable;
            }
        }

        /// <summary>
        /// Tells the player that the card cannot be played (or discarded) out of their turn:
        /// the message goes through GameEvents.OnActionRefused, shown by the error toast, and by the tutorial during a lesson.
        /// </summary>
        protected void ReportNotYourTurn(ICard card, bool discard)
        {
            PlayerController player = PlayerController.Local;

            if (player == null || player.Object == null || !player.Object.IsValid)
                return;
            GameActionError error = new GameActionError
            {
                Scope       = ErrorScope.Local,
                Target      = player.Object.InputAuthority,
                Severity    = ErrorSeverity.Minor,
                Location    = discard ? ErrorLocation.Discard : ErrorLocation.Table,
                MessageKey  = discard ? "Table_Discard_NotYourTurn" : "Table_Play_NotYourTurn",
                MessageArgs = new GameActionErrorArgs(card != null ? card.ID.ToString() : "-1")
            };

            GameEvents.OnActionRefused.Invoke(error, GameActionError.Localize(error));
        }

        protected GameObject GetHandDisplay(ICard card)
            => PlayerController.Local.Context.HandManager.GetCardDisplayGO(card);

        #endregion

        #region Drop Handling

        public virtual void OnDrop(PointerEventData eventData)
        {
            DraggableCard drag = eventData.pointerDrag?.GetComponent<DraggableCard>();

            if (drag == null || slot == null)
                return;

            if (!IsMyTurn)
            {
                drag.ReturnToOriginalPosition();

                ReportNotYourTurn(drag.GetCard(), false);

                return;
            }

            ICard card = drag.GetCard();

            if (card == null)
            {
                drag.ReturnToOriginalPosition();

                return;
            }

            if (EffectPromptState.IsActive(EffectPromptKind.Discard))
            {
                drag.ReturnToOriginalPosition();
                EffectPromptState.BlockIfPending();

                return;
            }

            // Tutorial: a card the current step doesn't allow goes back to the hand.
            if (!Vermines.Tutorial.Integration.TutorialGameHooks.AllowCardDrop(card, false))
            {
                drag.ReturnToOriginalPosition();

                return;
            }

            if (!slot.CanAcceptCard(card))
            {
                drag.ReturnToOriginalPosition();

                // Tutorial: explains why the card cannot go there (tool on the table, table full).
                Vermines.Tutorial.Integration.TutorialGameHooks.ReportRefusedDrop(card, false);

                return;
            }

            // A slot already showing a card, or a full table: the card would cover a partisan already placed.
            if (IsSlotTaken || IsTableFull)
            {
                drag.ReturnToOriginalPosition();

                Vermines.Tutorial.Integration.TutorialGameHooks.ReportRefusedDrop(card, false);

                return;
            }

            ApplyOptimistically(card, drag);

            RequestAction(card);
        }

        // Applies the visual change IMMEDIATELY, before any server response.
        // Extension point for subclasses (Discard renders differently: the
        // slot shows the discarded card, not a played one).
        protected virtual void ApplyOptimistically(ICard card, DraggableCard drag)
        {
            GameObject handDisplay = GetHandDisplay(card);

            if (handDisplay != null)
                handDisplay.SetActive(false);

            slot.Init(card, true, new TableCardClickHandler(slot.GetIndex()));

            _PendingCard = card;
        }

        // Sends the request to the server. Extension point (Discard routes
        // through a different mechanism than Play).
        protected virtual void RequestAction(ICard card)
        {
            GameEvents.OnCardPlayedRequested.Invoke(card);
        }

        #endregion

        #region Rollback on refusal

        // Called when the server refuses the action. Rolls back the visual
        // change applied by ApplyOptimistically, restoring the card to hand.
        protected virtual void OnActionRefused(ICard card)
        {
            if (_PendingCard == null || card != _PendingCard)
                return; // not our pending action: ignore

            _PendingCard = null;

            RestoreHandCard(card);
            slot.ResetSlot();
        }

        // Re-displays the card in hand and returns it to its original
        // position. Reused as-is by DiscardDropHandler.
        protected void RestoreHandCard(ICard card)
        {
            GameObject handDisplay = GetHandDisplay(card);

            if (handDisplay == null)
                return;
            handDisplay.SetActive(true);

            if (handDisplay.TryGetComponent<DraggableCard>(out var drag))
            {
                drag.ReturnToOriginalPosition();
                drag.gameObject.SetActive(true);
            }
        }

        #endregion
    }
}
