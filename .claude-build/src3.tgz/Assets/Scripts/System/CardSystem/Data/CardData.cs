﻿using System.Collections.Generic;
using UnityEngine;

namespace Vermines.CardSystem.Data {

    using Vermines.CardSystem.Enumerations;
    using Vermines.CardSystem.Data.Effect;

    [CreateAssetMenu(fileName = "New Card", menuName = "Vermines/Card System/Create a new card")]
    public class CardData : ScriptableObject {

        #region Information

        /// <summary>
        /// The name of the card.
        /// </summary>
        public string Name;

        /// <summary>
        /// Number of exemplars of the card in the shop.
        /// </summary>
        public int Exemplars = 1;

        /// <summary>
        /// Is the card in the default deck of players?
        /// </summary>
        public bool IsStartingCard = false;

        /// <summary>
        /// Number of exemplars in each player starting deck.
        /// </summary>
        [SerializeField]
        private int _DeckExemplars = 0;

        public int DeckExemplars
        {
            get => IsStartingCard ? _DeckExemplars : 0;
            set
            {
                if (IsStartingCard)
                    _DeckExemplars = value;
                else
                    _DeckExemplars = 0;
            }
        }

        #endregion

        #region Properties

        /// <summary>
        /// The type of the card.
        /// </summary>
        public CardType Type = CardType.None;

        /// <summary>
        /// Did the card belongs to a family of a player?
        /// </summary>
        public bool IsFamilyCard = false;

        /// <summary>
        /// The family of the card. Only available if the card has a partisan type. (Default: None)
        /// </summary>
        [SerializeField]
        private CardFamily _Family = CardFamily.None;

        /// <summary>
        /// Get or set the family of the card. Only available if the card has a partisan type. (Default: None)
        /// </summary>
        public CardFamily Family
        {
            get => Type == CardType.Partisan ? _Family : CardFamily.None;
            set
            {
                if (Type == CardType.Partisan)
                    _Family = value;
                else
                    _Family = CardFamily.None;
            }
        }

        /// <summary>
        /// The level of the card. Only partisan can have levels.
        /// The level is used to determine the power of the card. It can only be between 1 and 2.
        /// </summary>
        [SerializeField]
        private int _Level = 0;

        /// <summary>
        /// Get or set the level of the card. Only partisan can have levels.
        /// </summary>
        public int Level
        {
            get => Type == CardType.Partisan ? _Level : 0;
            set
            {
                if (Type == CardType.Partisan)
                    _Level = Mathf.Clamp(value, 1, 2);
                else
                    _Level = 0;
            }
        }

        #endregion

        #region Effects

        public List<AEffect> Effects = new();

        private List<AEffect> _OriginalEffect;

        public void CopyEffect(List<AEffect> effects)
        {
            _OriginalEffect = new List<AEffect>(Effects);

            Effects = effects;
        }

        public void RemoveEffectCopied()
        {
            _OriginalEffect ??= new List<AEffect>(Effects); // If the _Original effect not exists.

            Effects = new List<AEffect>(_OriginalEffect);
        }

        public bool ReduceInSilence = false;

        public bool HasEffectOfType(EffectType type)
        {
            foreach (AEffect effect in Effects) {
                if ((effect.Type & type) != 0)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Return true if their is at least two effects of different types.
        /// </summary>
        public bool HasChoiceEffect()
        {
            HashSet<EffectType> types = new();

            foreach (AEffect effect in Effects) {
                if (types.Contains(effect.Type))
                    return true;
                types.Add(effect.Type);
            }

            return false;
        }

        /// <summary>
        /// Return true if their is at least two effects (given) of the same type.
        /// </summary>
        public bool HasChoiceEffect(EffectType type)
        {
            HashSet<EffectType> types = new();

            foreach (AEffect effect in Effects) {
                if ((effect.Type & type) != 0) {
                    if (types.Contains(effect.Type))
                        return true;
                    types.Add(effect.Type);
                }
            }

            return false;
        }

        #endregion

        #region Stats

        /// <summary>
        /// If the tool has no exemplars in shop and is only in players deck, it can't be recycled to gain eloquence.
        /// </summary>
        public bool CanBeRecycled()
        {
            if (Type != CardType.Tools)
                return false;
            if (Exemplars > 0)
                return true;
            return false;
        }

        [SerializeField]
        private int _RecycleEloquence = 0;

        public int RecycleEloquence
        {
            get => Type == CardType.Tools ? _RecycleEloquence : 0;
            set
            {
                if (Type == CardType.Tools)
                    _RecycleEloquence = value;
                else
                    _RecycleEloquence = 0;
            }
        }

        /// <summary>
        /// The cost of the card (with Eloquence as the currency).
        /// </summary>
        [SerializeField]
        private int _Eloquence = 0;
        /// <summary>

        /// Get or set the cost of the card (with Eloquence as the currency).
        /// </summary>
        public int Eloquence
        {
            get => _Eloquence;
            set
            {
                _Eloquence = value;

                CurrentEloquence = _Eloquence;
            }
        }

        public bool IsFree = false;

        /// <summary>
        /// The current eloquence value of the card.
        /// Use it in the UI, for know if the value has changed or not.
        /// </summary>
        public int CurrentEloquence = 0;

        /// <summary>
        /// The eloquence that are not reduced because the card is already at the minimum cost.
        /// </summary>
        private int _ExcessiveEloquence = 0;

        /// <summary>
        /// Function for reducing the eloquence of the card.
        /// </summary>
        public void EloquenceReduction(int amount)
        {
            if (CurrentEloquence - amount < 1) {
                _ExcessiveEloquence += (1 - (CurrentEloquence - amount));

                CurrentEloquence = 1;
            } else {
                CurrentEloquence -= amount;
            }

            CurrentEloquence = Mathf.Clamp(CurrentEloquence, 1, _Eloquence);
        }

        /// <summary>
        /// Function that remove the reduction of the eloquence of the card.
        /// </summary>
        public void RemoveReduction(int amount)
        {
            if (_ExcessiveEloquence > 0 && amount < _ExcessiveEloquence) {
                _ExcessiveEloquence -= amount;
            } else if (_ExcessiveEloquence > 0) {
                amount -= _ExcessiveEloquence;

                _ExcessiveEloquence = 0;

                CurrentEloquence += amount;
            } else {
                CurrentEloquence += amount;
            }

            CurrentEloquence = Mathf.Clamp(CurrentEloquence, 1, _Eloquence);
        }

        /// <summary>
        /// The souls of the card (souls represent the points system of the game).
        /// </summary>
        [SerializeField]
        private int _Souls = 0;

        /// <summary>
        /// Get or set the souls of the card (souls represent the points system of the game).
        /// </summary>
        public int Souls
        {
            get => Type == CardType.Partisan ? _Souls : 0;
            set
            {
                if (Type == CardType.Partisan)
                    _Souls = value;
                else
                    _Souls = 0;
                CurrentSouls = _Souls;
            }
        }

        /// <summary>
        /// The current souls value of the card.
        /// Use it in the UI, for know if the value has changed or not.
        /// </summary>
        public int CurrentSouls = 0;

        private int _ExcessiveSouls = 0;

        public void SoulsReduction(int amount)
        {
            if (CurrentSouls - amount < 0) {
                _ExcessiveSouls = Mathf.Abs(CurrentSouls);

                CurrentSouls = 0;
            } else {
                CurrentSouls -= amount;
            }
        }

        public void RemoveSoulsReduction(int amount)
        {
            if (_ExcessiveSouls > 0 && amount < _ExcessiveSouls)
                _ExcessiveSouls -= amount;
            else if (_ExcessiveSouls > 0) {
                amount -= _ExcessiveSouls;

                CurrentSouls += amount;
                _ExcessiveSouls = 0;
            } else {
                CurrentSouls += amount;
            }
        }

        #endregion

        #region UI Elements

        /// <summary>
        /// The sprite name of the visual, an item, or a character that represents the card.
        /// Given that the card is a family card.
        /// </summary>
        [SerializeField]
        private string _SpriteName = string.Empty;

        /// <summary>
        /// Get or set the sprite name of the visual
        /// </summary>
        public string SpriteName
        {
            get => IsFamilyCard ? _SpriteName : string.Empty;
            set
            {
                if (IsFamilyCard)
                    _SpriteName = value;
                else
                    _SpriteName = string.Empty;
            }
        }

        /// <summary>
        /// The sprite of the visual, an item, or a character that represents the card.
        /// </summary>
        [SerializeField]
        private Sprite _Sprite = null;

        /// <summary>
        /// Get or set the sprite of the visual
        /// </summary>
        public Sprite Sprite
        {
            get => !IsFamilyCard ? _Sprite : null;
            set
            {
                _Sprite = value;
            }
        }

        public List<(string, Sprite)> Draw()
        {
            if (Effects == null || Effects.Count == 0)
                return null;
            if (Effects.Count == 1 && Effects[0] != null)
                return Effects[0].Draw();
            else if (Effects.Count == 1)
                return null;
            List<(string, Sprite)> elements  = new();
            Sprite                 separator = Resources.Load<Sprite>("Sprites/UI/Effects/separator");

            for (int i = 0; i < Effects.Count; i++) {
                if (Effects[i] == null)
                    continue;
                elements.AddRange(Effects[i].Draw());

                if (i < Effects.Count - 1)
                    elements.Add(("Separator", separator));
            }
            return elements;
        }

        #endregion

        #region Helpers

        public bool CanBeDiscard()
        {
            if (Type != CardType.Partisan)
                return true;
            foreach (var effect in Effects) {
                if ((effect.Type & EffectType.Discard) != 0)
                    return true;
            }

            return false;
        }

        #endregion
    }
}
